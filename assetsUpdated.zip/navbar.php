<nav class="navbar navbar-default">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
            <li><a href="home_company.php">Company</a></li>
            <li><a href="home_employee.php">Employee</a></li>
            <li><a href="home_salaryRegular.php">Salary</a></li>
            <li><a href="home_payment.php">Payment</a></li>
            <li><a href="home_bill.php">Bill</a></li>
            <li><a href="home_salaryRegular.php">View</a></li>


        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a data-toggle="modal" href="#colins"><span class="glyphicon glyphicon-user"></span> Admin</a></li>
        </ul>
    </div>
</nav>
