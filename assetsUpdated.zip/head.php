
<!DOCTYPE html>
<html lang="en">
<head>

    <!-- Meta, title, CSS, favicons, etc. -->


    <title></title>

    <script>
        <!--
        var ScrollMsg= "M/S. JAHID PRINTERS & AD- "
        var CharacterPosition=0;
        function StartScrolling() {
            document.title=ScrollMsg.substring(CharacterPosition,ScrollMsg.length)+
                ScrollMsg.substring(0, CharacterPosition);
            CharacterPosition++;
            if(CharacterPosition > ScrollMsg.length) CharacterPosition=0;
            window.setTimeout("StartScrolling()",150); }
        StartScrolling();
        // -->
    </script>

    
</head>
