<!-- BOOTSTRAP STYLES-->
<link href="css/bootstrap.css" rel="stylesheet" />
<!-- FONTAWESOME STYLES-->
<link href="css/font-awesome.css" rel="stylesheet" />
   <!--CUSTOM BASIC STYLES-->
<link href="css/basic.css" rel="stylesheet" />
<!--CUSTOM MAIN STYLES-->
<link href="css/custom.css" rel="stylesheet" />
<link href="assets/css/remark.css" rel="stylesheet">


<script src="assets/jquery/billCalculation.js" type="text/javascript"></script>
<script src="assets/js/ajax.js" type="text/javascript"></script>
<script src="assets/jquery/stockOperation.js" type="text/javascript"></script>

<!-- GOOGLE FONTS-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<script src="js/jquery-1.10.2.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gijgo@1.9.6/js/gijgo.min.js" type="text/javascript"></script>
<script src="assets/jquery/paymentCalcualtion.js" type="text/javascript"></script>
<link href="https://cdn.jsdelivr.net/npm/gijgo@1.9.6/css/gijgo.min.css" rel="stylesheet" type="text/css" />


<!-- <link href="data:text/css;charset=utf-8," data-href="assets/css/bootstrap-theme.min.css" rel="stylesheet" id="bs-theme-stylesheet"> -->
<!-- <link href="assets/css/docs.min.css" rel="stylesheet"> -->
<link href="assets/css/search.css" rel="stylesheet">
<link href="assets/css/bootstrap-datepicker.css" rel="stylesheet">
<link href="css/bootstrap-datepicker.css" rel="stylesheet">
<link href="css/panal.css" rel="stylesheet">
<!-- <link rel="stylesheet" href="assets/css/styles.css" /> -->
<link rel="stylesheet" type="text/css" href="assets/css/dataTables.min.css">
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<!-- <script src="assets/js/docs.min.js"></script> -->
<script src="assets/js/search.js"></script>
<script type="text/javascript" charset="utf-8" language="javascript" src="assets/js/dataTables.min.js"></script>
<script src="assets/bootstrap/js/bootstrap-datetimepiker.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap-datetimepiker.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="js/bootstrap-datepicker.js" type="text/javascript"></script>

   <link href="assets/css/remark.css" rel="stylesheet">
   <script src="assets/jquery/billCalculation.js" type="text/javascript"></script>
   <script src="assets/js/ajax.js" type="text/javascript"></script>
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
   
<!-- React Table Links -->   
   

