<?php
  include("first.php"); //include auth.php file on all secure pages



  $id=$_REQUEST['emp_id'];

  $query  = "SELECT * from employee where emp_id='".$id."'";
  $q = $conn->query($query);
while($row = $q->fetch_assoc())
  {
    $name = $row['fname'].' ' .$row['lname'];
  }
?>
<?php
include("php/headerCompany.php");
?>
        <div id="page-wrapper">
            <div id="page-inner">




<div class="row">
    <div class="col-md-12">
        <h1 class="page-head-line"><?php echo $name; ?></h1>
        <h1 class="page-subhead-line">Welcome to <strong><?php echo ' '. $siteName ?></strong> Today is:
        <i class="icon-calendar icon-large" ></i>


        <?php
        date_default_timezone_set("Asia/Dhaka");
        echo  date(" l, F d, Y") . "<br>";

        ?>
         </h1>

    </div>
</div>
      <?php
        $id=$_REQUEST['emp_id'];

      $query  = "SELECT * from employee where emp_id='".$id."'";
      $q = $conn->query($query);
      while($row = $q->fetch_assoc())
        {

          ?>

              <form class="form-horizontal" action="update_employee.php" method="post" name="form">
                <input type="hidden" name="new" value="1" />
                <input name="id" type="hidden" value="<?php echo $row['emp_id'];?>" />

                  <div class="form-group">
                    <label class="col-sm-5 control-label">Firstname  :</label>
                    <div class="col-sm-4">
                      <input type="text" name="fname" class="form-control" value="<?php echo $row['fname'];?>" required="required">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-5 control-label">Lasttname  :</label>
                    <div class="col-sm-4">
                      <input type="text" name="lname" class="form-control" value="<?php echo $row['lname'];?>" required="required">
                    </div>
                  </div>
                  <div class="form-group">
                      <label class="col-sm-5 control-label">Mobile No  :</label>
                      <div class="col-sm-4">
                          <input type="text" name="mobile" class="form-control" value="<?php echo $row['mobileNo'];?>" required="required">
                      </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-5 control-label">Gender  :</label>
                    <div class="col-sm-4">
                    <select name="gender" class="form-control" required>
                      <option value="<?php echo $row['gender'];?>"><?php echo $row['gender'];?></option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                  </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-5 control-label">Employee Type  :</label>
                    <div class="col-sm-4">
                      <select name="emp_type" class="form-control" required>
                        <option value="<?php echo $row['emp_type'];?>"><?php echo $row['emp_type'];?></option>
                        <option value="Job Order">Job Order</option>
                        <option value="Regular">Regular</option>
                        <option value="Casual">Casual</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-5 control-label">Department  :</label>
                    <div class="col-sm-4">
                      <select name="division" class="form-control" placeholder="Division" required>
                        <option value="<?php echo $row['division'];?>"><?php echo $row['division'];?></option>
                        <option value="Admin">Admin</option>
                        <option value="Human Resource">Human Resource</option>
                        <option value="Accounting">Accounting</option>
                        <option value="Engineering">Engineering</option>
                        <option value="MIS">MIS</option>
                        <option value="Supply">Supply</option>
                        <option value="Maintenance">Maintenance</option>
                        <option value="Maintenance">Artist</option>
                        <option value="Maintenance">Painters</option>
                        <option value="Maintenance">Sign Bord</option>
                        <option value="Control">Control</option>
                      </select>
                    </div>
                    </div>
                     <div class="form-group">
                      <label class="col-sm-5 control-label">Salary  :</label>
                      <div class="col-sm-4">
                          <input type="text" name="salary" class="form-control" value="<?php echo $row['salary'];?>" required="required">
                      </div>
                  </div><br><br>

                  <div class="form-group">
                    <label class="col-sm-5 control-label"></label>
                    <div class="col-sm-4">
                      <input type="submit" name="submit" value="Update" class="btn btn-danger">
                      <a href="home_employee.php" class="btn btn-primary">Cancel</a>
                    </div>
                  </div>

              </form>
            <?php
          }
        ?>

      <!-- this modal is for my Colins -->
      <div class="modal fade" id="colins" role="dialog">
        <div class="modal-dialog modal-sm">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header" style="padding:20px 50px;">
              <button type="button" class="close" data-dismiss="modal" title="Close">&times;</button>
              <h3 align="center">You are logged in as <b><?php echo $_SESSION['username']; ?></b></h3>
            </div>
            <div class="modal-body" style="padding:40px 50px;">
              <div align="center">
                <a href="logout.php" class="btn btn-block btn-danger">Logout</a>
              </div>
            </div>
          </div>
        </div>
      </div>



    <!-- this function is for modal -->
    <script>
      $(document).ready(function()
      {
        $("#myBtn").click(function()
        {
          $("#myModal").modal();
        });
      });
    </script>

    <?php
  include("last.php");
?>
