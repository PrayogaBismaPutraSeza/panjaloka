<?php

include("first.php");
include("add_dailyTransaction.php");


$query  = "SELECT * from deductions WHERE deduction_id='1'";
$q = $conn->query($query);
while($row = $q->fetch_assoc())
  {
  }
?>
<?php
include("php/header.php");
?>
        <div id="page-wrapper">
            <div id="page-inner">

<div class="row">
    <div class="col-md-12">
        <h1 class="page-head-line">My Daily Transactions</h1>
        
        
                   
           <style type="text/css">
           .different-text-color { color: green; }
        </style>

       <marquee>  <h1 class="page-subhead-line"><p style="font-size:x-large;"><span class="different-text-color">WELCOME TO--DAILY TRANSACTIONS @ <strong><?php echo ' '. $siteName ?></strong> @@@ Today is:
        <i class="icon-calendar icon-large" ></i>


        <?php
        date_default_timezone_set("Asia/Dhaka");
        echo  date(" l, F d, Y") . "<br>";

        ?>
         </span></p></h1> </marquee>

    </div>
</div>

          <div class="well bs-component">
              
              <form class="form-horizontal" action="#" name="form" method="post">
                 <div class="form-group">
                            <label class="col-sm-4 control-label">Date :</label>
                            <div class="col-sm-5">

                                <input class="form-control" id="datepicker" name="t_date" type="text" value = "<?php echo $thisDate; ?>" />
                                <script>
                                    $('#datepicker').datepicker({
                                        uiLibrary: 'bootstrap4'
                                    });
                                </script>
                            </div>
                        </div>

                <div class="form-group">
                    <label class="col-sm-4 control-label">Transaction Cause :</label>
                    <div class="col-sm-5">
                        <input type="text" name="cause" class="form-control" placeholder="Enter Transaction Cause" required="required">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-4 control-label"> Transaction Amount :</label>
                    <div class="col-sm-5">
                        <input type="text" name="amount" class="form-control" placeholder="Enter Amount" required="required">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-4 control-label">Transaction method :</label>
                    <div class="col-sm-5">
                        <input type="radio" name="method"  value="cash" required="required">Cash &nbsp;&nbsp;
                        <input type="radio" name="method" value="bkash" required="required">Bkash


                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-4 control-label">Remark :</label>
                    <div class="col-sm-5">
                        <input type="text" name="remark" class="form-control" placeholder="Enter remark">
                    </div>
                </div>
                

                <div class="form-group">
                  <label class="col-sm-4 control-label"></label>
                  <div class="col-sm-5">
                    <input type="submit" name="submit" class="btn btn-success" value="Submit">
                    <input type="reset" name="" class="btn btn-danger" value="Clear Fields">
                  </div>
                </div>
              </form>
              <br><br>
            <form class="form-horizontal">
                
              <fieldset>

                <br><br>
                <div class="table-responsive">
                  <form method="post" action="" >
                    <table class="table table-bordered table-hover table-condensed" id="myTable">
                      <!-- <h3><b>Ordinance</b></h3> -->
                      <thead>
                        <tr class="info">
                          <th><p align="center">Serial No</p></th>
                          <th><p align="center">Date</p></th>
                          <th><p align="center">Cause</p></th>
                          <th><p align="center">Amount</p></th>
                            <th><p align="center">Method</p></th>
                            <th><p align="center">Remark</p></th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php




                          $query = "select * from transaction where delete_status = '0' ORDER BY sno asc ";
                        $q = $conn->query($query);
                        $serial = 0;
                        while($row = $q->fetch_assoc())
                          {
                              
                            $serial++;
                            $sno     =$row['sno'];
                            $date = date('d/m/Y', strtotime($row['t_date']));
                            $cause   =$row['cause'];
                            $amount  =$row['amount'];
                            $method  =$row['method'];
                            $remark  =$row['remark'];



                        ?>

                        <tr>
                          <td align="center" scope="row"><a href="view_transection.php?sno=<?php echo $row["sno"]; ?>" title="Update">  <?php echo $serial ?></a></td>
                          <td align="center" ><a  href="view_transection.php?sno=<?php echo $row["sno"]; ?>" title="Update"><?php echo $date ?></a></td>
                          <td align="center"><a  href="view_transection.php?sno=<?php echo $row["sno"]; ?>" title="Update"><?php echo $cause?></a></td>
                          <td align="center"><a  href="view_transection.php?sno=<?php echo $row["sno"]; ?>" title="Update"><?php echo $amount?></a></td>
                          
                            <td align="center"><a  href="view_transection.php?sno=<?php echo $row["sno"]; ?>" title="Update"><?php echo $method ?></a></td>
                            <td align="center"><a  href="view_transection.php?sno=<?php echo $row["sno"]; ?>" title="Update"><?php echo $remark ?></a></td>

                        </tr>

                        <?php } ?>
                      </tbody>
                      <tr class="info">
                          <th><p align="center">Serial No</p></th>
                          <th><p align="center">Date</p></th>
                          <th><p align="center">Cause</p></th>
                          <th><p align="center">Amount</p></th>
                            <th><p align="center">Method</p></th>
                            <th><p align="center">Remark</p></th>
                        </tr>

                    </table>
                    
                  </form>
                </div>
              </fieldset>
            </form>
         
            
          </div>

      <!-- this modal is for Deleting Transaction -->
        
     

      <!-- this modal is for my Colins -->
      <div class="modal fade" id="colins" role="dialog">
        <div class="modal-dialog modal-sm">

          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header" style="padding:20px 50px;">
              <button type="button" class="close" data-dismiss="modal" title="Close">&times;</button>
              <h3 align="center">You are logged in as <b><?php echo $_SESSION['username']; ?></b></h3>
            </div>
            <div class="modal-body" style="padding:40px 50px;">
              <div align="center">
                <a href="logout.php" class="btn btn-block btn-danger">Logout</a>
              </div>
            </div>
          </div>
        </div>
      </div>




    <!-- this function is for modal -->
    <script>
      $(document).ready(function()
      {
        $("#myBtn").click(function()
        {
          $("#myModal").modal();
        });
      });
    </script>
    <script src="assets/js/jquery.min.js" ></script>
   <script src="assets/js/ddtf.js" ></script>
   
    <script>
      
        $("#myTable").ddTableFilter();
    </script>



        <?php

        include ("last.php");

        ?>
