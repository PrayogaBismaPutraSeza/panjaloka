<!DOCTYPE html>
<html>
<head>

</head>
<body>
<style>
div {
    height: 1000px;
    width: 50%;
    background-color: powderblue;
}

</style>

<h1>M/S. JAHID PRINTERS & AD </h1>



<div></div>

</body>
</html>
