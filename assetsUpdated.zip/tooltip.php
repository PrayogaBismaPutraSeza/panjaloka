									<script type="text/javascript">
											$(document).ready(function(){                                     
                                            $('#login').tooltip('show')
                                            $('#login').tooltip('hide')
                                        });
                                    </script>
									<script type="text/javascript">
											$(document).ready(function(){                                     
                                            $('#signup').tooltip('show')
                                            $('#signup').tooltip('hide')
                                        });
                                    </script>
										<script type="text/javascript">
											$(document).ready(function(){                                     
                                            $('#home').tooltip('show')
                                            $('#home').tooltip('hide')
                                        });
                                    </script>
										<script type="text/javascript">
											$(document).ready(function(){                                     
                                            $('#aboutus').tooltip('show')
                                            $('#aboutus').tooltip('hide')
                                        });
                                    </script>
										<script type="text/javascript">
											$(document).ready(function(){                                     
                                            $('#contactus').tooltip('show')
                                            $('#contactus').tooltip('hide')
                                        });
                                    </script>
										<script type="text/javascript">
											$(document).ready(function(){                                     
                                            $('#services').tooltip('show')
                                            $('#services').tooltip('hide')
                                        });
                                    </script>
										<script type="text/javascript">
											$(document).ready(function(){                                     
                                            $('#reservation').tooltip('show')
                                            $('#reservation').tooltip('hide')
                                        });
                                    </script>